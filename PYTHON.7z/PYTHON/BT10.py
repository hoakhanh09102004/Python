x=int(input("nhập x="))
y=int(input("nhập y="))
print("kết quả của x+y là:",x+y)
