def tinh_tong_so_nguyento_tu_chuoi(so_a, so_b):
    
    so_a_nguyen = int(so_a)
    so_b_nguyen = int(so_b)

    tong = so_a_nguyen + so_b_nguyen

    print("Tổng hai số là:", tong)

if __name__ == "__main__":
    so_a = input("Nhập số a: ")
    so_b = input("Nhập số b: ")

    # Gọi hàm để tính tổng hai số
    tinh_tong_so_nguyento_tu_chuoi(so_a, so_b)