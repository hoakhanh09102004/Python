def check_chia_het_cho_5(so_nhi_phan):
    so_thapphan = int(so_nhi_phan, 2)
   
    return so_thapphan % 5 == 0

def main():
    so_nhi_phan_list = input("Nhập vào chuỗi các số nhị phân: ")

    danh_sach_so_nhi_phan = so_nhi_phan_list.split(",")

    danh_sach_so_chia_het_cho_5 = []

    for so_nhi_phan in danh_sach_so_nhi_phan:
        if check_chia_het_cho_5(so_nhi_phan):
            danh_sach_so_chia_het_cho_5.append(so_nhi_phan)

    print("Các số chia hết cho 5:", ",".join(danh_sach_so_chia_het_cho_5))


if __name__ == "__main__":
    main()