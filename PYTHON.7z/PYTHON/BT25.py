def in_hoan_vi(arr):
    for i in range(len(arr)):
        for j in range(i + 1, len(arr)):
            arr[i], arr[j] = arr[j], arr[i]
            print(arr)
            arr[i], arr[j] = arr[j], arr[i]
arr = [1, 2, 3]
in_hoan_vi(arr)