n = int(input("Nhập vào chiều dài: "))
m = int(input("Nhập vào chiều rộng: "))
for i in range(m):
    for j in range(n):
        if i == 0 or i == m - 1 or j == 0 or j == n - 1:
            print("*", end="")
        else:
            print(" ", end="")
    print()
