def nam(n):
    if n % 4 == 0 :
        return ("năm nhuận")
    else:
        return("năm bình thường")
print(nam(2020))