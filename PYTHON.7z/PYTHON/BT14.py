def inhoa(n):
    return (n.upper())
print(inhoa("hello world"))