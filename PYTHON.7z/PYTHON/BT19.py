input_str = input("Nhập vào danh sách các số: ")
numbers = list(map(int, input_str.split(',')))
odd_numbers = [number for number in numbers if number % 2 != 0]
print("Các số lẻ từ danh sách:", odd_numbers)