def chanle(n):
    if n % 2 == 0 :
        return ("chẵn")
    else:
        return("lẻ")
print(chanle(4))