n = int(input("Nhập vào chiều dài: "))
m = int(input("Nhập vào chiều rộng: "))

for i in range(m):
    for j in range(n):
        print("*", end="")
    print()