str = input("Nhập chuỗi: ")

for i in range(len(str)):
    if i % 2 == 0:
        print(str[i])