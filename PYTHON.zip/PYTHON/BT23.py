def kiem_tra_so(so_nguyen):
    if so_nguyen % 2 == 0:
        print("Đây là một số chẵn")
    else:
        print("Đây là một số lẻ")


if __name__ == "__main__":
    so_nguyen = int(input("Nhập số nguyên: "))
    kiem_tra_so(so_nguyen)