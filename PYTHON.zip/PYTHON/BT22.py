def in_chuoi_dai_nhat(chuoi_a, chuoi_b):

    len_a = len(chuoi_a)
    len_b = len(chuoi_b)

    if len_a > len_b:
        print(chuoi_a)
    elif len_b > len_a:
        print(chuoi_b)
    else:
        print(chuoi_a)
        print(chuoi_b)


if __name__ == "__main__":
    chuoi_a = input("Nhập chuỗi a: ")
    chuoi_b = input("Nhập chuỗi b: ")

    in_chuoi_dai_nhat(chuoi_a, chuoi_b)