def tinh_tong(so_a, so_b):
    tong = so_a + so_b
    return tong
