def binhphuong(n):
    bp=n*n
    return (bp)
print(binhphuong(5))