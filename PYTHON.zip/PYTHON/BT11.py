def print_all_binary_strings(n):
    strings = []
    for i in range(2**n):     
        binary_string = format(i, "b").zfill(n)
        strings.append(binary_string)

    for string in strings:
        print(string)
print(print_all_binary_strings(4))
