n = int(input("Nhập vào số nguyên: "))
sodaonguoc = 0
while n != 0:
    sodaonguoc = sodaonguoc * 10 + n % 10
    n //= 10

print("Số đảo ngược:", sodaonguoc)