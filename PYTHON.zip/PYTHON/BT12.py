def giaithua(n):
    gt=1
    for i in range(1,n+1,1):
        gt=gt*i
    return (gt)
print(giaithua(5))    