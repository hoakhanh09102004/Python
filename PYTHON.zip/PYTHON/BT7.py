sentence = input("Nhập vào câu tiếng Anh: ")
word_count = 0
for word in sentence.split():
    word_count += 1

char_count = 0
for char in sentence:
    char_count += 1

print("Trong câu có:", word_count, "từ và", char_count, "ký tự.")